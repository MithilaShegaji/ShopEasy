// const express = require('express');
// const router = express.Router();

// router.get('/search', (req, res) => {
//     res.render('searchPage', { errorMessage: null });
// });

// module.exports = router;
