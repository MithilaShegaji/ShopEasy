const axios = require('axios');
const cheerio = require('cheerio');
const Product = require('../Models/productModel');
const Wishlist = require('../Models/wishlistModel');

// Scraping function for Flipkart
async function scrapeFlipkart(productName) {
    try {
        const response = await axios.get(`https://www.flipkart.com/search?q=${productName}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const $ = cheerio.load(response.data);
        let products = [];
        $('._1AtVbE').each((index, element) => {
            let title = $(element).find('._4rR01T').text().trim();
            let price = $(element).find('._30jeq3').text().trim();
            let link = `https://www.flipkart.com${$(element).find('a').attr('href')}`;
            let image = $(element).find('img').attr('src');
            if (title && price && link && image) {
                products.push({ title, price, link, image, source: 'Flipkart' });
            }
        });
        return products;
    } catch (error) {
        console.error('Error scraping Flipkart:', error.message);
        return [];
    }
}

// Scraping function for Amazon
async function scrapeAmazon(productName) {
    try {
        const response = await axios.get(`https://www.amazon.in/s?k=${productName}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const $ = cheerio.load(response.data);
        let products = [];
        $('.s-main-slot .s-result-item').each((index, element) => {
            let title = $(element).find('.a-text-normal').text().trim();
            let price = $(element).find('.a-price .a-offscreen').text().trim();
            let link = `https://www.amazon.in${$(element).find('.a-link-normal').attr('href')}`;
            let image = $(element).find('img').attr('src');
            if (title && price && link && image) {
                products.push({ title, price, link, image, source: 'Amazon' });
            }
        });
        return products;
    } catch (error) {
        console.error('Error scraping Amazon:', error.message);
        return [];
    }
}

// Scraping function for Myntra
async function scrapeMyntra(productName) {
    try {
        const response = await axios.get(`https://www.myntra.com/${productName}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const $ = cheerio.load(response.data);
        let products = [];
        $('.product-base').each((index, element) => {
            let title = $(element).find('h3').text().trim();
            let price = $(element).find('span[data-qa="product-price"]').text().trim();
            let link = `https://www.myntra.com${$(element).find('a').attr('href')}`;
            let image = $(element).find('img').attr('src');
            if (title && price && link && image) {
                products.push({ title, price, link, image, source: 'Myntra' });
            }
        });
        return products;
    } catch (error) {
        console.error('Error scraping Myntra:', error.message);
        return [];
    }
}

// Scraping function for ShopClues
async function scrapeShopClues(productName) {
    try {
        const response = await axios.get(`https://www.shopclues.com/search?q=${productName}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const $ = cheerio.load(response.data);
        let products = [];
        $('.product-grids .product').each((index, element) => {
            let title = $(element).find('.prodname').text().trim();
            let price = $(element).find('.p_price .p_price_value').text().trim();
            let link = `https://www.shopclues.com${$(element).find('a').attr('href')}`;
            let image = $(element).find('img').attr('src');
            if (title && price && link && image) {
                products.push({ title, price, link, image, source: 'ShopClues' });
            }
        });
        return products;
    } catch (error) {
        console.error('Error scraping ShopClues:', error.message);
        return [];
    }
}

// Scraping function for Limeroad
async function scrapeLimeroad(productName) {
    try {
        const response = await axios.get(`https://www.limeroad.com/search/${productName}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const $ = cheerio.load(response.data);
        let products = [];
        $('.product-item').each((index, element) => {
            let title = $(element).find('.product-title').text().trim();
            let price = $(element).find('.price').text().trim();
            let link = `https://www.limeroad.com${$(element).find('a').attr('href')}`;
            let image = $(element).find('img').attr('src');
            if (title && price && link && image) {
                products.push({ title, price, link, image, source: 'Limeroad' });
            }
        });
        return products;
    } catch (error) {
        console.error('Error scraping Limeroad:', error.message);
        return [];
    }
}

// Scraping function for eBay
async function scrapeEbay(productName) {
    try {
        const response = await axios.get(`https://www.ebay.com/sch/i.html?_nkw=${productName}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const $ = cheerio.load(response.data);
        let products = [];
        $('.s-item').each((index, element) => {
            let title = $(element).find('.s-item__title').text().trim();
            let price = $(element).find('.s-item__price').text().trim();
            let link = $(element).find('.s-item__link').attr('href');
            let image = $(element).find('.s-item__image-img').attr('src');
            if (title && price && link && image) {
                products.push({ title, price, link, image, source: 'eBay' });
            }
        });
        return products;
    } catch (error) {
        console.error('Error scraping eBay:', error.message);
        return [];
    }
}

// Scraping function for Walmart
async function scrapeWalmart(productName) {
    try {
        const response = await axios.get(`https://www.walmart.com/search/?query=${productName}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const $ = cheerio.load(response.data);
        let products = [];
        $('.search-result-gridview-item').each((index, element) => {
            let title = $(element).find('.product-title').text().trim();
            let price = $(element).find('.price-main').text().trim();
            let link = `https://www.walmart.com${$(element).find('a').attr('href')}`;
            let image = $(element).find('img').attr('src');
            if (title && price && link && image) {
                products.push({ title, price, link, image, source: 'Walmart' });
            }
        });
        return products;
    } catch (error) {
        console.error('Error scraping Walmart:', error.message);
        return [];
    }
}

// Scraping function for Ajio
async function scrapeAjio(productName) {
    try {
        const response = await axios.get(`https://www.ajio.com/search/?text=${productName}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const $ = cheerio.load(response.data);
        let products = [];
        $('.item').each((index, element) => {
            let title = $(element).find('.title').text().trim();
            let price = $(element).find('.price').text().trim();
            let link = `https://www.ajio.com${$(element).find('a').attr('href')}`;
            let image = $(element).find('img').attr('src');
            if (title && price && link && image) {
                products.push({ title, price, link, image, source: 'Ajio' });
            }
        });
        return products;
    } catch (error) {
        console.error('Error scraping Ajio:', error.message);
        return [];
    }
}

// Scraping function for TataCliq
async function scrapeTataCliq(productName) {
    try {
        const response = await axios.get(`https://www.tatacliq.com/search?q=${productName}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const $ = cheerio.load(response.data);
        let products = [];
        $('.product-card').each((index, element) => {
            let title = $(element).find('.product-title').text().trim();
            let price = $(element).find('.price').text().trim();
            let link = `https://www.tatacliq.com${$(element).find('a').attr('href')}`;
            let image = $(element).find('img').attr('src');
            if (title && price && link && image) {
                products.push({ title, price, link, image, source: 'TataCliq' });
            }
        });
        return products;
    } catch (error) {
        console.error('Error scraping TataCliq:', error.message);
        return [];
    }
}

// Scraping function for Meesho
async function scrapeMeesho(productName) {
    try {
        const response = await axios.get(`https://www.meesho.com/search?q=${productName}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const $ = cheerio.load(response.data);
        let products = [];
        $('.product-card').each((index, element) => {
            let title = $(element).find('.product-title').text().trim();
            let price = $(element).find('.product-price').text().trim();
            let link = `https://www.meesho.com${$(element).find('a').attr('href')}`;
            let image = $(element).find('img').attr('src');
            if (title && price && link && image) {
                products.push({ title, price, link, image, source: 'Meesho' });
            }
        });
        return products;
    } catch (error) {
        console.error('Error scraping Meesho:', error.message);
        return [];
    }
}

// Scraping function for Only.in
async function scrapeOnlyIn(productName) {
    try {
        const response = await axios.get(`https://www.only.in/search?q=${productName}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const $ = cheerio.load(response.data);
        let products = [];
        $('.product-item').each((index, element) => {
            let title = $(element).find('.product-title').text().trim();
            let price = $(element).find('.price').text().trim();
            let link = `https://www.only.in${$(element).find('a').attr('href')}`;
            let image = $(element).find('img').attr('src');
            if (title && price && link && image) {
                products.push({ title, price, link, image, source: 'Only.in' });
            }
        });
        return products;
    } catch (error) {
        console.error('Error scraping Only.in:', error.message);
        return [];
    }
}

// Exporting the function
module.exports = {
    scrapeFlipkart,
    scrapeAmazon,
    scrapeMyntra,
    scrapeShopClues,
    scrapeLimeroad,
    scrapeEbay,
    scrapeWalmart,
    scrapeAjio,
    scrapeTataCliq,
    scrapeMeesho,
    scrapeOnlyIn
};